require('./bootstrap');
require('bootstrap-colorpicker');

$(document).ready(function() {
    $('#color').colorpicker();
});
